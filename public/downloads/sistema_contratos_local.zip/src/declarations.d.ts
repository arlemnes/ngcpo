declare module 'react-quill';
